
import numpy as np
import scipy
import soundfile as sf
from scipy import signal
import matplotlib.pyplot as plt

from stft_mdl import spectrum as st
from stft_mdl import display as ds

data, sr = sf.read('0002_01_.wav')
data =signal.resample(data,8000)

D =np.abs(st.stft(data, n_fft=258)) #D =np.abs(librosa.stft(data, n_fft=258))

print(D.shape)

ds.specshow(st.amplitude_to_db(abs(D), ref=np.max), x_axis='time')
plt.title('Power spectrogram')
plt.colorbar(format='%+2.0f dB')
plt.xticks(range(0, 1))
plt.tight_layout()
plt.show()



