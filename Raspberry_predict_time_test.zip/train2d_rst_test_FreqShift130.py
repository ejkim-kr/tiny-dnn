
import os
from keras.models import load_model
import numpy as np
import soundfile as sf
import librosa
from scipy import signal
import time

model_wav = load_model('model_2d_100p_hjpr4man.h5') #'model_2d_100p.h5') #'model_2d_100p_hjpr4man.h5' sample base =130000)

idir = './test_voice_outside_hoo/' #test_voice_outside_cho, test_voice_outside_hoo, test_voice_outside_stone, test_voice_inside_root

fileList = os.listdir(idir)
file_cnt = len(fileList)

maxLen =0
Tn = 0
Ts = 0
print('  Step,  Len,   sr,  Rows,  Max,  Min, MaxR, MinR,   Sum, mean, pred,     fname,   sec')

for fname in fileList:
    start = time.time()
    
    data0, sr = sf.read(idir+fname)
    dLen = len(data0)

    '''
    #고음강조 => 중성화 => 예측율? (45%->94%)
    rate_emphasis = 0.95 #클수록 고음이 강조됨
    emphasized_data = data0[0:-1] - data0[1:] * rate_emphasis
    emphasized_data =np.append(emphasized_data,[0]) 
    '''
    #data = signal.resample(emphasized_data,8000) #주파수 변조
    rsd = np.zeros(shape=(130000)) #학습 데이터 모양
    rsd[0:len(data0)] = data0
    data = signal.resample(rsd,8000)
    #data = signal.resample(data0,8000)

    D1 = np.abs(librosa.stft(data, n_fft=258))

    Drs = np.sum(D1, axis=1); DrsR = Drs/Drs.sum(); DrsRI = DrsR.cumsum(); DrsRIwh= np.where(DrsRI>=0.5) # gen_GC
    ORGDrsRIwh =DrsRIwh[0][0]
 
    #if DrsRIwh[0][0] < 100: #30:   # 학습 데이터의 표준 음성 GCenter = 30
    if abs(DrsRIwh[0][0] -30) >=0: #30:   # 학습 데이터의 표준 음성 GCenter = 30        
        RR= DrsRIwh[0][0]/28  #4k로 하면 매우 정확, 현재는 130,126
        #if RR >1.3: RR =1.3
        #if RR <0.7: RR =0.7

        rsd = np.zeros(shape=(130000)) #학습 데이터 모양, train base => shape=(130000)
        reSmplLen =int(dLen*RR)
        if reSmplLen >130000: reSmplLen =130000 # 너무 길면 뒤를 삭제
        data = signal.resample(data0, reSmplLen) # Gravity Center 
        rsd[0:len(data)] = data
        data = signal.resample(rsd,8000)
        D2 = np.abs(librosa.stft(data, n_fft=258))
        Drs = np.sum(D2, axis=1); DrsR = Drs/Drs.sum(); DrsRI = DrsR.cumsum(); DrsRIwh= np.where(DrsRI>=0.5) # gen_GC
    
    ###########
    D2= D2.reshape([1,130,126,1])
    y_pred = model_wav(D2, training=False) 
    labelNum = np.argmax(y_pred[0])
    ###########
    
    '''
    ################ 2개 중 우세 선택 #무의미
    D0 =np.concatenate([D1, D2], 0)
    D0= D0.reshape([2,130,126,1])
    y_pred = model_wav(D0, training=False) 

    labelNum1 = np.argmax(y_pred[0])
    lblSum1 =np.sum(y_pred[0])
    labelNum2 = np.argmax(y_pred[1])
    lblSum2 =np.sum(y_pred[1])

    labelNum =labelNum1 if y_pred[0][labelNum1]/lblSum1 > y_pred[1][labelNum2]/lblSum2 else labelNum2
    ################
    '''

    if int(fname[5:7])==labelNum: Tn+=1; Tnsg='O'
    else: Tnsg='X'

    end = time.time()
    print('%5d->%7d %5d %5d %5d %06.2f %04.2f %5d %5d %04.2f %05.2f %5d %s %0.3f %s %2.2f' 
           %(ORGDrsRIwh, DrsRIwh[0][0], dLen, sr, len(Drs), Drs.max(),Drs.min(), Drs.argmax(), Drs.argmin(), Drs.sum(), Drs.mean(),labelNum, fname,end-start, Tnsg, y_pred[0][labelNum]))

print('O_Step  N_Step, Len,   sr, Rows,   Max, Min,  MaxR, MinR,   Sum,  mean, pred,        fname,   sec')
print('maxLen=',maxLen, sr, int(Ts/file_cnt))
print(Tn,len(fileList), Tn/len(fileList), len(fileList)-Tn)